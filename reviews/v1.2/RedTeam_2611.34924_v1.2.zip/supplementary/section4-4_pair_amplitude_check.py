import mpmath as mp
mp.mp.dps=30
# (4.33): sum_k 2*(1/(2 s k))^2 e^{-2ik/s} = Li2(e^{-2i/s})/(2 s^2)
for s in [10,100,1000]:
    S=mp.nsum(lambda k: 2*(1/(2*s*k))**2*mp.exp(-2j*k/s),[1,mp.inf])
    print(s, mp.nstr(S*2*s**2,12), mp.nstr(mp.polylog(2,mp.exp(-2j/s)),12))
# G->0 limit (s->inf) of s^2 * amplitude without phase: zeta(2)/2 finite
print("no-phase limit s^2*A =", mp.zeta(2)/2)
# non-analyticity: Li2(e^{-i t}) - pi^2/6 vs t*log t
for t in [1e-2,1e-4,1e-6]:
    d=mp.polylog(2,mp.exp(-1j*t))-mp.pi**2/6
    print(t, mp.nstr(d,8), mp.nstr(-1j*t*(1-mp.log(1j*t)),8))
