# v1.6 citation revision verification

The introduction credits Oppenheim’s public commentary and the contemporaneous GitHub case study. The clock section discusses the conditional construction in (C.11)–(C.13) and cites the Evidence Press candidate with its stated linearized scope. The discussion of Proposition 7 identifies the generalized Kantorovich constant and the Specht ratio, with primary-source references. The theorem statements, mathematical proofs and computational inputs were preserved.

Three LuaLaTeX runs were performed with the adjacent logo, then three from the TeX alone. The final logs showed no errors, undefined references or box warnings. The two 35-page PDFs had identical extracted text page by page. The recovered PNG matched the original byte for byte. Every page was rendered and reviewed, with individual inspection of the cover, affected body pages, transparency statement and complete reference list. The bibliography occupies page 35.

The four documented Python entry points and the pinned Lean project were rerun on the same mathematical inputs. See the archived receipts and the citation revision logs in `reproduction/reference/`. These checks cover the formal implications and the finite diagnostics. The independent unnormalized bound for the gravitational construction remains open.
