"""Finite diagnostic checks for the additional conditional results, not formal proofs."""
import numpy as np
from fractions import Fraction
rng=np.random.default_rng(261134924)
for n in (4,8,16,32):
    for _ in range(20):
        u,_=np.linalg.qr(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))
        v,_=np.linalg.qr(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))
        U=u@np.diag(np.linspace(.4,1.2,n))@v.conj().T
        D=np.diag(rng.uniform(.3,1,n))
        T=(U@D).conj().T@(U@D)
        eig=np.linalg.eigvalsh(T)
        assert eig[0] >= .4**2*.3**2-1e-12 and eig[-1]<=1.2**2+1e-12
        k=n//2; P=v[:,:k]@v[:,:k].conj().T
        rho=P@T@P/np.trace(P@T).real
        K=np.outer(u[:,0],u[:,0].conj())
        assert np.trace(rho@K).real<=1.2**2/(.4**2*.3**2*k)+1e-12
        # Noncommuting clock and comparison form: u_clock = L + positive matrix.
        L=np.diag(np.arange(n,dtype=float)); B=u@np.diag(rng.uniform(0,3,n))@u.conj().T
        clock=L+B
        cutoff=n/2; R=cutoff+.1
        assert np.count_nonzero(np.linalg.eigvalsh(clock)<=cutoff)<=np.count_nonzero(np.arange(n)<=R)
print('Coercivity, compact-test bound and comparison spectral rank: 80 seeded finite instances passed.')
# exact weighted discrete nested family: u_i=i, w_i=i, Z(N)=N(N+1)/2.
# The limiting mean ratio is q=2/3 and clock CDF exponent q/(1-q)=2.
for N in (100,1000,10000):
    Z=lambda n: n*(n+1)//2
    q=Fraction(2*N+1,3*N)
    assert q-Fraction(2,3)==Fraction(1,3*N)
    for t in (Fraction(1,4),Fraction(1,2),Fraction(3,4)):
        ratio=Fraction(Z(int(t*N)),Z(N))
        assert abs(ratio-t*t)<=Fraction(1,N)
print('Exact discrete regular-variation example: clock ratios and exponent passed.')
print('Scope: illustrative finite checks; gravitational realization, analytic proofs, and Lean are separate.')
