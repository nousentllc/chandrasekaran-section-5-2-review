"""Verify finite examples of the replica and entropy bounds with a fixed floor."""

from fractions import Fraction as F
from itertools import product

import mpmath as mp


def higher_moment_constants(floor, order):
    slope = (1 - floor**order) / (1 - floor)
    offset = slope - 1
    mean = order * offset / ((order - 1) * slope)
    bound = (slope * mean - offset) / mean**order
    return mean, bound


def check_spectra():
    spectrum_count = 0
    moment_count = 0
    complement_count = 0
    with mp.workdps(70):
        tolerance = mp.mpf("1e-62")
        for floor in (F(1, 10), F(1, 4), F(1, 2), F(3, 4), F(1)):
            levels = (floor, (1 + floor) / 2, F(1))
            bounds = {}
            for order in range(2, 6):
                if floor == 1:
                    bounds[order] = F(1)
                    continue
                optimal_mean, constant = higher_moment_constants(floor, order)
                unit_fraction = (optimal_mean - floor) / (1 - floor)
                assert 0 < unit_fraction < 1
                endpoint_moment = unit_fraction + (1 - unit_fraction) * floor**order
                assert endpoint_moment / optimal_mean**order == constant
                if order == 2:
                    assert constant == (1 + floor)**2 / (4 * floor)
                bounds[order] = constant
            mp_floor = mp.mpf(floor.numerator) / floor.denominator
            entropy_bound = mp.mpf(0)
            if floor < 1:
                a = -mp_floor * mp.log(mp_floor) / (1 - mp_floor)
                entropy_bound = a - 1 - mp.log(a)
                fraction = (a - mp_floor) / (1 - mp_floor)
                endpoint_deficit = (
                    (1 - fraction) * mp_floor * mp.log(mp_floor) / a - mp.log(a)
                )
                assert abs(endpoint_deficit - entropy_bound) < tolerance
            for rank in range(1, 6):
                for weights in product(levels, repeat=rank):
                    total = sum(weights)
                    for order, bound in bounds.items():
                        scaled = rank**(order - 1) * sum(x**order for x in weights) / total**order
                        assert 1 <= scaled <= bound
                        moment_count += 1
                    purity = sum(x**2 for x in weights) / total**2
                    for split in range(1, rank):
                        left, right = weights[:split], weights[split:]
                        bound = (sum(x**2 for x in left) + sum(right)**2 / len(right)) / total**2
                        assert purity >= bound
                        complement_count += 1
                    probs = [
                        mp.mpf(p.numerator) / p.denominator
                        for p in (x / total for x in weights)
                    ]
                    deficit = mp.log(rank) + sum(p * mp.log(p) for p in probs)
                    assert -tolerance <= deficit <= entropy_bound + tolerance
                    spectrum_count += 1
    return spectrum_count, moment_count, complement_count


def check_off_diagonal_block():
    # T = [[1/2, 1/8], [1/8, 3/4]] has eigenvalues in [1/4, 1].
    a, b, x, floor = F(1, 2), F(3, 4), F(1, 8), F(1, 4)
    assert (a - floor) * (b - floor) > x**2
    assert (1 - a) * (1 - b) > x**2
    purity = (a**2 + b**2 + 2 * x**2) / (a + b)**2
    block_bound = (a**2 + b**2) / (a + b)**2
    assert purity - block_bound == 2 * x**2 / (a + b)**2 > 0
    return purity, block_bound


def main():
    spectra, moments, splits = check_spectra()
    print(f"{moments} exact rational moment checks at orders 2 through 5")
    print(f"{spectra} entropy-deficit checks at 70 decimal digits")
    print(f"{splits} exact rational regular/complement splits")
    actual, bound = check_off_diagonal_block()
    print(f"Noncommuting block sample: purity = {actual}; block bound = {bound}")
    print("Finite diagnostics. The analytic statements hold for arbitrary real orders p > 1.")


if __name__ == "__main__":
    main()
