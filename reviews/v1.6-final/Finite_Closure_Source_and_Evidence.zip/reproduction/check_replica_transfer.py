"""Exact rational finite-dimensional tests for the replica ratio statements.
These are implementation diagnostics, not proofs of gravitational closure.
Run without Python -O (assertions are used).
"""
from fractions import Fraction as F
from itertools import product

cases = 0
for c in (F(1,10), F(1,4), F(1,2), F(3,4), F(1)):
    values = (c, (1+c)/2, F(1))
    for d in range(1, 6):
        for weights in product(values, repeat=d):
            z = sum(weights)
            for n in (2, 3, 4):
                ratio = sum(x**n for x in weights)/z**n
                assert 0 < ratio <= z**(1-n)
                assert ratio <= (c*d)**(1-n)
            r2 = sum(x*x for x in weights)/z**2
            assert F(1,d) <= r2 <= (1+c)**2/(4*c*d)
            for k in range(1,d+1):
                sub=weights[:k]; a=sum(sub); b=sum(x*x for x in sub)
                missing_ratio=(z-a)/a
                assert r2 >= (b/a**2)/(1+missing_ratio)**2
            cases += 1
print(f'{cases} exact rational diagonal spectra: D.47, positive floor, sharpened purity-rank bound and subspace-transfer inequality passed.')
for m in (1, 4, 13):
    for N in (0,1,100,10000):
        a=F(2,5); z=(m+N)*a; z2=(m+N)*a*a
        assert z2/z**2 == F(1,m+N)
print('12 exact dilution tests passed: fixed positive regular ratio, exhaustive ratio decays with added multiplicity.')
print('Scope: exact finite arithmetic for abstract controls only; no interacting gravitational ratio or Lean verification.')
