import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace GluingBound

/-- Average this inequality over the eigenvalues of a finite compression. -/
theorem square_le_of_mem_interval (c x : ℝ) (lower : c ≤ x) (upper : x ≤ 1) :
    x ^ 2 ≤ (1 + c) * x - c := by
  nlinarith [mul_nonneg (sub_nonneg.mpr lower) (sub_nonneg.mpr upper)]

/-- The inputs μ and second are the first and second moments of the cut eigenvalues.
The gluing identification of the physical ratio is outside this statement. -/
theorem replica_upper (c n μ second : ℝ) (hc : 0 < c) (hn : 0 < n) (hμ : 0 < μ)
    (hsecond : second ≤ (1 + c) * μ - c) :
    second / (n * μ ^ 2) ≤ (1 + c) ^ 2 / (4 * c * n) := by
  have left_denominator : 0 < n * μ ^ 2 := by positivity
  have right_denominator : 0 < 4 * c * n := by positivity
  apply (div_le_div_iff₀ left_denominator right_denominator).2
  have scaled := mul_le_mul_of_nonneg_left hsecond (show 0 ≤ 4 * c by positivity)
  have square_bound : 4 * c * ((1 + c) * μ - c) ≤ (1 + c) ^ 2 * μ ^ 2 := by
    nlinarith [sq_nonneg ((1 + c) * μ - 2 * c)]
  have result := mul_le_mul_of_nonneg_right (scaled.trans square_bound) hn.le
  convert result using 1 <;> ring

end GluingBound

#print axioms GluingBound.square_le_of_mem_interval
#print axioms GluingBound.replica_upper
