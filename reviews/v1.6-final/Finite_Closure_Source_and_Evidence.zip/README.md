# Finite Closure in Null-Cone Quantization of Gravity

Justin Candler, Nous Enterprises LLC. The archive contains the editable source and verification evidence for the comprehensive research preprint. It reviews [arXiv:2611.34924v1](https://arxiv.org/abs/2611.34924v1). Earlier work appears in the [pinned repository snapshot](https://github.com/nousentllc/chandrasekaran-section-5-2-review/tree/909450e1e8e818ebf94c6e1877e662e2b27c162f).

## Build

Verify the archive manifest and compile `Finite_Closure.tex` with LuaLaTeX. The original Nous PNG is available beside the source and embedded in the TeX for standalone use. Run LuaLaTeX three times to resolve the references and contents.

```sh
shasum -a 256 -c SHA256SUMS
for run in 1 2 3; do
  lualatex -interaction=nonstopmode -halt-on-error Finite_Closure.tex
done
```

The publication PDF was rebuilt after a citation and bibliography update. The release manifest identifies the exact PDF, standalone TeX and source ZIP. Independent builds can differ in PDF IDs or metadata. [The verification record](VERIFICATION.md) distinguishes receipts for the publication build from the previously reviewed v1.6 baseline.

## Reproduction

```sh
cd reproduction
python -m pip install -r requirements.txt
python run_checks.py
python check_additional_results.py
python check_replica_transfer.py
python check_spectral_capacity.py
```

The seven original scripts, the 80 seeded matrix cases, the regular-variation example, 1,815 rational spectra and 12 dilution checks passed on fresh execution. The additional script checks higher spectral moments, complementary-block lower bounds and the von Neumann entropy deficit. The fresh and archived outputs are labeled in [the verification record](VERIFICATION.md).

Build the pinned Lean project from the same `reproduction/` directory.

```sh
lake exe cache get
lake build
lake env lean TraceDimCheck.lean
lake env lean TraceDimBasis.lean
lake env lean CycleBound.lean
lake env lean ReplicaBound.lean
```

The Lean checks cover the conditional trace/rank and signed-cut inequalities, the basis-to-dimension step, and the scalar second-moment inequality. The manuscript proves the higher moments, entropy, compactness and positive sewing criteria analytically. Applying them to the exact gravitational preparation requires the physical estimates stated in the text.
