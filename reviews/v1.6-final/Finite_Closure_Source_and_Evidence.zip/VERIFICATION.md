# Verification of the revised manuscript

## Publication citation update

The publication package incorporates the citation and bibliography update to the reviewed v1.6 manuscript. The numerical and Lean receipts below record the prior review and validation. They identify the checked mathematics independently of this typesetting update.

- Publication Finite_Closure.tex SHA-256: 719d678d7c9cf55dffb95a8b6b3d7d9aa8f8ea3a2f6970331f725eb3ca388e83
- Publication Finite_Closure.pdf SHA-256: 8c0cd42927d22237ef3488b6f33de9a421496e4d32f831580711c4d9e7c6f773

### Publication build receipts

- [citation-revision-lean-build.log](reproduction/reference/citation-revision-lean-build.log)
- [citation-revision-python.log](reproduction/reference/citation-revision-python.log)
- [publication-build.md](reproduction/reference/publication-build.md)

## Reviewed v1.6 baseline

### Environment

- macOS 27.0.1, build 26A434, Apple silicon.
- LuaHBTeX 1.24.0, TeX Live 2026.
- Python 3.13.2, NumPy 2.3.5, SymPy 1.13.3, mpmath 1.3.0.
- Lean 4.35.0, commit `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`, with Lake and the checked-in package manifest. Mathlib checkout `56a005855ea17e0b0958f73ec801ae140b0a1679`.

### Fresh execution

| Check | Result | Receipt |
| --- | --- | --- |
| Three LuaLaTeX invocations with the adjacent PNG and again from the TeX alone | Identical per-page extracted text, 34 pages. Final builds report no errors, undefined references or box warnings. The recovered PNG matches the original byte for byte. | Commands in [README](README.md). |
| Seven original Python checks | All passed. Operator and countermodel JSON match the archived outputs byte for byte. | [fresh-original.log](reproduction/reference/fresh-original.log) |
| Stability, compact tests, comparison rank and regular variation | 80 seeded matrix checks and the exact discrete regular-variation example passed. | [fresh-additional.log](reproduction/reference/fresh-additional.log) |
| Second-moment estimates and replica dilution | 1,815 rational spectra and 12 dilution cases passed. | [fresh-replica.log](reproduction/reference/fresh-replica.log) |
| Higher moments and entropy | 7,260 exact moment checks, 6,390 exact complementary-block splits, 1,815 entropy checks at 70 digits and one noncommuting block example passed. | [fresh-spectral-capacity.log](reproduction/reference/fresh-spectral-capacity.log) |
| Lean pinned build and three earlier proof files | Build and all six declarations passed. The build retains the existing warning about importing Mathlib from a non-module file. | [build](reproduction/reference/fresh-lean-build.log) · [axiom report](reproduction/reference/fresh-lean.log) |
| Lean scalar square and replica bound | Both declarations passed with the same axiom list. | [fresh-lean-replica.log](reproduction/reference/fresh-lean-replica.log) |

The checks printed `propext`, `Classical.choice` and `Quot.sound` as the axiom dependencies. The prior logs under `reproduction/reference/` remain archived. The diagonal spectrum tests establish finite arithmetic diagnostics. The physical limit estimate requires a separate gravitational argument.

For the primary-source attribution, the printed arXiv v1 PDF pp. 42–43 was compared directly with the TeX discussion. Reference [5] was checked against the publisher's Crossref deposit. References [7] and [8] were retrieved from the exact commit URLs. The cover, page sequence, new derivations, bibliography and final pages were reviewed in the rendered PDF.
